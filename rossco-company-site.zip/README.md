# The Rossco Company Inc. - Professional Website

Welcome to the official repository for **The Rossco Company Inc.**, a premium painting and restoration company specializing in:

- Custom luxury residential painting
- Collaborations with high-end interior designers
- Commercial and government institution projects
- Custom wall treatments and exterior restorations

Our clients include renowned builders, design firms, commercial enterprises, and government organizations.

## Live Website
👉 [View Website on GitHub Pages](https://your-github-username.github.io/rossco-company-site/)

## Features

- Modern responsive design using **TailwindCSS**
- Smooth animations with **AOS (Animate on Scroll)**
- Professional gallery showcasing real projects
- Contact form ready for integration
- Fully optimized for **GitHub Pages** deployment

## Technologies Used

- HTML5 & CSS3
- TailwindCSS via CDN
- AOS.js for animations
- Hosted images on PostImages

## Folder Structure

rossco-company-site/
├── index.html
├── README.md

## How to Deploy

1. Fork or clone this repository.
2. Go to GitHub > Settings > Pages.
3. Select the `main` branch as source.
4. Save and wait for GitHub Pages to build your site.
5. Your site will be available at `https://your-github-username.github.io/rossco-company-site/`

## Contact

**The Rossco Company Inc.**  
Hamilton, Ontario, Canada  
Email: rosscoatings@hotmail.com

> Crafted with dedication and passion for excellence.
